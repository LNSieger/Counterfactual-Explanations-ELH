from owlapy._utils import MOVE
from owlapy.owlready2._base import OWLOntologyManager_Owlready2, OWLReasoner_Owlready2, OWLOntology_Owlready2,\
    BaseReasoner_Owlready2
MOVE(OWLOntologyManager_Owlready2, OWLReasoner_Owlready2, OWLOntology_Owlready2, BaseReasoner_Owlready2)
__all__ = 'OWLOntologyManager_Owlready2', 'OWLReasoner_Owlready2', 'OWLOntology_Owlready2', 'BaseReasoner_Owlready2'

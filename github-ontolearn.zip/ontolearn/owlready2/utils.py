def get_full_iri(x):
    return x.namespace.base_iri + x.name

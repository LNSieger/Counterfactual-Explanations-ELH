Ontolearn API
=============

.. autosummary::
   :toctree: source
   :recursive:

   ontolearn
   owlapy
